import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import Imputer
from mlxtend.frequent_patterns import apriori, association_rules


def load_data():

    # read column headers
    column_titles = []
    with open("census-income.names", 'r') as f:
        for line in f:
            # remove comments from name file
            if line[0] not in ['|', '-', '\n']:
                column_titles.append(line.split(': ')[0])

    # add column indicating if person earns more than 50K
    column_titles.append("more than 50000")

    data = pd.read_csv("census-income.data", sep=", ", names=column_titles, 
                       index_col=False, engine="python")

    return data


def clean_data(rawdata):

    # Remove duplicates
    num_values = len(rawdata)
    data = rawdata.drop_duplicates()
    print("Dropped %s duplicates from data set" %(num_values-len(data)))

    # Seach for null values
    missing_numbers = data.isnull().sum().sort_values(ascending=False).head()
    print(missing_numbers)
    data.dropna(axis=1, inplace=True)

    return data


def combine_categories(df):

    # combine birth countries of self, mother, and father into two options:
    # "United-States" or "Other"

    US = "United-States"

    self = "country of birth self"
    df[self]   = [US if c == US else 'Other' for c in df[self]]

    mother = "country of birth mother"
    df[mother] = [US if c == US else 'Other' for c in df[mother]]

    father = "country of birth father"
    df[father] = [US if c == US else 'Other' for c in df[father]]

    
    # combine 'Not in universe' with 'Other' category for state of previous
    # residence
    spr = "state of previous residence"
    df[spr] = ['Not in universe' if x == 'Not in universe' else 'Other' for x in df[spr]]


    # Create two categories for citizenship: born in the US and 'Other'
    native = "Native- Born in the United States"
    df['citizenship'] = [native if x == native else 'Other' for x in df['citizenship']]

    # combine categories for household status
    df['detailed household and family stat'] =  ['Child <18 never marr not in subfamily ' 
            if x == 'Child <18 never marr not in subfamily ' 
            else 'Other' 
         'Spouse of householder' 
            if x == 'Spouse of householder' 
            else 'Other' 
         'Child 18+ never marr Not in a subfamily' 
            if x== 'Child 18+ never marr Not in a subfamily' 
            else 'Other'
         'Secondary individual' 
            if x == 'Secondary individual' 
            else 'Other'
         for x in df['detailed household and family stat']]

    return df


def dummy_df(df, todummy_list):
    for x in todummy_list:
        dummies = pd.get_dummies(df[x], prefix=x, dummy_na=False)
        df = df.drop(x, 1)
        df = pd.concat([df, dummies], axis=1)
    return df


if __name__ == "__main__":

    # load and clean the data (remove duplicates, fix missing values)
    data = clean_data(load_data())

    # find number of unique attributes in each category and combine some of 
    # them. (In this case, just combine county of birth self, mother, father
    # to be either "United States" or "Other")
    #get_categories(data)
    data = combine_categories(data)

    # convert data to dummies dataframe
    dummies = []
    for col in data.columns:
        if data[col].dtypes == 'object':
            dummies.append(col)

    data = dummy_df(data, dummies)

    # write data to CSV file
    #data.to_csv('census-income.csv', index=False, quoting=2)

    # search for association rules
    for col in data:
        print(col)
        df = data.filter(like=col)
        df['income'] = data['more than 50000_50000+.']

        frequent_items = apriori(df, min_support=0.05, 
                                 use_colnames=True)
        rules = association_rules(frequent_items, metric="lift", 
                                  min_threshold=1)
        print(rules)
        print("\n\n\n")
