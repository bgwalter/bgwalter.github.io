import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from optparse import OptionParser


def load_data(filename):
    return np.genfromtxt(filename, dtype="U25", delimiter=",")


def write_to_file(filename, results):
    with open(filename, 'w') as f:
        for line in results:
            f.write("%s,%s\n" %(line[0], line[1]))


def create_graph(proteins):
    '''
    Create a network graph from a list of protein pairs

    Parameters
    ----------
    proteins : list of tuples
        A list of all protein pair tuples e.g. [(p1, p2), (p3, p3), ...]

    Returns
    -------
    G : ~networkx.Graph
        A graph of all protein pairs in the form of a networkx Graph object
    '''
    G = nx.Graph()
    G.add_edges_from(proteins)
    return G


def draw_graph(G, color=None):
    '''
    Draw a graph using matplotlib

    Parameters
    ----------
    G : ~networkx.Graph
        A networkx Graph object of protein-protein interactions
    '''

    #TODO plot cancerous proteins separately

    pos = nx.drawing.nx_agraph.graphviz_layout(G)

    nx.draw(G, pos, node_size=10, node_color=color)
    plt.show()


def calc_function_weight(pp, pf, function, cancers):
    '''
    The weight of a function is defined as the number of protein neighbors
    which are cancers. As in, if a function has 2 neighbors which are cancer
    proteins, the weight of the function is 2.

    Parameters
    ----------
    pp : ~networkx.Graph
        Protein-protein interaction graph
    pf : ~networkx.Graph
        Protein-function graph
    function : string
        Function ID being measured
    cancers : list (1-d)
        A list of protein IDs which known to be related to cancer

    Returns
    -------
    weight : int
        The weight of the function
    '''

    weight = 0
    for neighbor in pf.neighbors(function):
        if neighbor in cancers:
            weight += len([*pp.neighbors(neighbor)])
    return weight


def calc_protein_weight(pp, pf, protein, cancers):
    '''
    The weight of a protein is determined by the sum of the weights of all
    neighboring functions. As in, if a protein has 2 functions with weights of
    3 and 4, then the weight of the protein is 7.

    Parameters
    ----------
    pp : ~networkx.Graph
        Protein-protein interaction graph where the proteins and the nodes and
        an edge is an interaction between nodes
    pf : ~networkx.Graph
        Protein-function graph where proteins and functions are both nodes and
        an edge indicates which functions belong to a protein
    protein : string
        protein ID being measured
    cancers : list (1-d)
        A list of protein IDs which known to be related to cancer

    Returns
    -------
    weight : int
        The weight of the protein
    '''

    weight = 0
    try:
        for function in pf.neighbors(protein):
            weight += calc_function_weight(pp, pf, function, cancers)
        return weight
    except nx.exception.NetworkXError:
        # Protein has no functions asscociated with it
        return -1


def calculate_weights(pp, pf, cancers):
    '''
    Calculate the weight of each protein

    Parameters
    ----------
    pp : ~networkx.Graph
        Protein-protein interaction graph where the proteins and the nodes and
        an edge is an interaction between nodes
    pf : ~networkx.Graph
        Protein-function graph where proteins and functions are both nodes and
        an edge indicates which functions belong to a protein
    cancers : list (1-d)
        A list of protein IDs which known to be related to cancer

    Returns
    -------
    weights : list (Nx2)
        A list containing the weights for each protein
        E.g., [ (<protein_ID>, <calculated weight>), ...]
    '''

    all_proteins = pp.nodes().keys()
    total = len(all_proteins)

    weights = []
    for i, protein in enumerate(all_proteins):
        weight = calc_protein_weight(pp, pf, protein, cancers)
        weights.append((protein, weight))

        if i % 50 == 0:
            print("%s/%s calculated" %(i, total))

    return weights


def make_predictions(weights, threshold):
    '''
    Predict if a protein is related to cancer or not. This is determined by its
    weight: if the weight is above a certain threshold, then it is related to
    cancer.

    Parameters
    ----------
    weights : list (Nx2)
        A list of protein IDs and their weights
    threshold : int
        The threshold above which a cancer protein is related to cancer
    '''

    predictions = []
    for protein, weight in weights:
        if int(weight) >= threshold:
            predictions.append((protein, "cancer"))
        else:
            predictions.append((protein, "nonCancer"))

    return predictions


def test2_predictions(test2, weights_file, threshold):
    '''
    Run predictions on the Test2.txt file

    Parameters
    ----------
    test2 : string
        path to Test2.txt
    weights_file : string
        path to file containing protein weights
    threshold : int
        threshold cutoff above which a protein is labeled as cancer
    '''

    test2 = load_data(test2)
    weights = load_data(weights_file)

    predictions = np.array(make_predictions(weights, threshold))

    test2_predictions = []
    for pid, pred in test2:
        index = np.where(predictions==pid)
        value = predictions[index[0],1][0]

        test2_predictions.append((pid, value))

    write_to_file("PredictionResultsTest2.txt", test2_predictions)


def main(path, threshold, test2=False):

    if test2:
        test2_predictions(path+"Test2.txt", "weights.txt", threshold)

    else:
        print("importing data")
        proteins = load_data(path+"humanPPI.txt")
        cancers = load_data(path+"Cancer.txt")
        functions = load_data(path+"Functions.txt")

        print("creating protein-protein graph")
        pp = create_graph(proteins)

        print("creating protein-function graph")
        pf = create_graph(functions)

        #draw_graph(pp)
        #draw_graph(pf)

        print("calculating weights")
        weights = calculate_weights(pp, pf, cancers)

        print("making cancer predictions")
        predictions = make_predictions(weights, threshold)

        write_to_file("weights.txt", weights)
        write_to_file("predictions.txt", predictions)


def option_parser():
    result = OptionParser()

    result.add_option("-p", "--path", dest="path", type="string",
                      default="./ResourceFiles/",
                      help="Path to data files  [%default]")
    result.add_option("-t", "--threshold", dest="threshold", type="int",
                      default=34700, help="Proteins with weights above this "
                      "value will be flagged as being related to cancer")
    result.add_option("--test2", dest="test2", action="store_true", default=False,
                      help="run predictions for Test2.txt")

    return result


if __name__ == "__main__":
    opt, arguments = option_parser().parse_args()
    main(**opt.__dict__)
