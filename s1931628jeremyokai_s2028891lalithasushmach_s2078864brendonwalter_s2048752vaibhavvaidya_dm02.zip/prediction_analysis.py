import numpy as np
import matplotlib.pyplot as plt

from predictions import *

def compare_predictions(predictions, comparisions):

    test_proteins = comparisions[:,0] # get protein IDs of proteins in test set

    tp, fp, tn, fn = 0, 0, 0, 0
    for pid, pred in predictions:
        if pid in test_proteins:
            # find if protein in the test set is cancerous or not
            index = np.where(comparisions==pid)
            value = comparisions[index[0],1]

            if value == "cancer":
                if pred == "cancer":
                    tp += 1
                elif pred == "nonCancer":
                    fn += 1

            if value == "nonCancer":
                if pred == "cancer":
                    fp += 1
                elif pred =="nonCancer":
                    tn += 1

    print("True positives:  %s" %tp)
    print("False positives: %s" %fp)
    print("True negatives:  %s" %tn)
    print("False negatives: %s" %fn)

    try:
        precision = round(float(tp / (tp + fp)), 3)
    except ZeroDivisionError:
        precision = -1

    recall    = round(float(tp / (tp + fn)), 3)
    fmeasure  = round(float((2*precision*recall) / (precision+recall)), 3)
    accuracy  = round(float((tp + tn) / (tp + fp + fn + tn)), 3)

    print("Precision: %s" %precision)
    print("Recall:    %s" %recall)
    print("F-measure: %s" %fmeasure)
    print("accuracy:  %s" %accuracy)


def weight_histogram(filename, numbins=100, no_functions=False):
    '''
    Create a histogram of the protein weights

    Parameters
    ----------
    filename : string
        Path to file with calculated protein weights
    numbins : int (default: 100)
        Number of bins in the histogram
    no_functions: boolean (default: False)
        Indicate inclusion of proteins which have not yet been functionally
        annotated in the histrogram
    '''

    weights = np.genfromtxt(filename, dtype="int", delimiter=',')[:,1]

    # negative weights indicate no functions
    negative = [x for x in filter(lambda a: a <  0, weights)]
    zero =     [x for x in filter(lambda a: a == 0, weights)]
    positive = [x for x in filter(lambda a: a >  0, weights)]

    max_weight = np.max(positive)
    avg_weight = round(np.average(zero+positive), 1)
    print("Total number of proteins: %s" %len(negative+zero+positive))
    print("Number of proteins with no functions: %s" %len(negative))
    print("Number of porteins with no cancer neighbors: %s" %len(zero))
    print("Max weight: %s" %max_weight)
    print("Avg weight: %s" %avg_weight)

    plt.figure(figsize=(10,5))

    if no_functions:
        plt.hist(negative+zero+positive, numbins, color='c')
    else:
        plt.hist(zero+positive, numbins, color='c')

    plt.axvline(np.average(zero+positive), linewidth=2, linestyle="dashed")

    plt.title("Protein weights\n Max: %s, Avg: %s" %(max_weight, avg_weight))
    plt.ylabel("Count")
    plt.xlabel("Weight")
    plt.tight_layout()

    plt.show()


def thresholds(weights, comps, t_min=0, t_max=100000, t_step=100):

    for threshold in range(t_min, t_max+t_step, t_step):
        print("Threshold: %s" %threshold)
        predictions = make_predictions(weights, threshold)
        compare_predictions(predictions, comps)
        print()


def threshold_analysis(filename):
    with open(filename, 'r') as f:
        data = f.readlines()

    data = [line.strip() for line in data]

    thresholds = []
    tp, fp, tn, fn = [], [], [], []
    precision = []
    recall = []
    fmeasure = []
    accuracy = []

    for line in data:
        if line.startswith("Threshold"):
            thresholds.append(int(line.split(':')[1]))
        elif line.startswith("True positive"):
            tp.append(int(line.split(':')[1]))
        elif line.startswith("False positive"):
            fp.append(int(line.split(':')[1]))
        elif line.startswith("True negative"):
            tn.append(int(line.split(':')[1]))
        elif line.startswith("False negative"):
            fn.append(int(line.split(':')[1]))
        elif line.startswith("Precision"):
            precision.append(float(line.split(':')[1]))
        elif line.startswith("Recall"):
            recall.append(float(line.split(':')[1]))
        elif line.startswith("F-measure"):
            fmeasure.append(float(line.split(':')[1]))
        elif line.startswith("accuracy"):
            accuracy.append(float(line.split(':')[1]))

    fig = plt.figure(figsize=(10,10))
    axes = fig.subplots(2, 1, sharex=True).flat

    axes[0].plot(thresholds, tp, label="true positive")
    axes[0].plot(thresholds, fp, label="false positive")
    axes[0].plot(thresholds, tn, label="true negative")
    axes[0].plot(thresholds, fn, label="false negative")
    axes[0].set_ylabel("Count")
    axes[0].legend()

    axes[1].plot(thresholds, precision, label="precision")
    axes[1].plot(thresholds, recall, label="recall")
    axes[1].plot(thresholds, fmeasure, label="fmeasure")
    axes[1].plot(thresholds, accuracy, label="accuracy")
    axes[1].set_ylabel("Measure")
    axes[1].set_ylim([0, 1.01])
    axes[1].legend()

    plt.xlabel("Threshold")
    plt.tight_layout()
    plt.show()


if __name__=="__main__":

    weight_histogram("weights.txt", numbins=50, no_functions=True)

    # read prediction set and test set from file
#    comps = np.genfromtxt("ResourceFiles/Test1.txt", dtype="U25", delimiter=",")
#    predictions = np.genfromtxt("predictions.txt", dtype="U25", delimiter=",")

#    compare_predictions(predictions, comps)

#    weights = np.genfromtxt("weights.txt", dtype="U25", delimiter=',')
#    thresholds(weights, comps)

    threshold_analysis("thresholds.txt")
